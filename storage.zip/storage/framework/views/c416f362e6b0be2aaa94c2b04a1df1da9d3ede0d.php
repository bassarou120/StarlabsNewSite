<?php if(theme_option('header_top_enabled')): ?>
    <?php echo Theme::partial('header-top'); ?>

<?php endif; ?>

<header class="header sticky-bar">
    <div class="container">
        <div class="main-header">
            <div class="header-left">
                <div class="header-logo">
                    <a class="d-flex" href="<?php echo e(route('public.index')); ?>">
                        <img alt="<?php echo e(theme_option('site_name')); ?>" src="<?php echo e(RvMedia::getImageUrl(theme_option('logo'))); ?>">
                    </a>
                </div>
                <div class="header-nav">
                    <nav class="nav-main-menu d-none d-xl-block">
                        <?php echo Menu::renderMenuLocation('main-menu', [
                                'options' => ['class' => 'main-menu'],
                                'view' => 'main-menu',
                            ]); ?>

                    </nav>
                    <div class="burger-icon burger-icon-white"><span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
                </div>

                <div class="header-right">
                    <?php if(is_plugin_active('blog') || is_plugin_active('ecommerce')): ?>
                        <div class="me-1 d-inline-block box-search-top">
                            <div class="form-search-top">
                                <form action="<?php echo e(is_plugin_active('blog') ? route('public.search') : route('public.products')); ?>">
                                    <input class="input-search" name="q" type="text" placeholder="<?php echo e(__('Search...')); ?>">
                                    <button class="btn btn-search">
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                        </svg>
                                    </button>
                                </form>
                            </div>
                            <span class="font-lg icon-list search-post">
                          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                          </svg>
                        </span>
                        </div>
                    <?php endif; ?>
                    <?php if(is_plugin_active('language')): ?>
                        <div class="d-none d-xl-inline-block">
                            <?php echo Theme::partial('language-switcher'); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(theme_option('action_button_text') && theme_option('action_button_url')): ?>
                        <div class="d-none d-sm-inline-block">
                            <a class="btn btn-brand-1 hover-up" href="<?php echo e(theme_option('action_button_url')); ?>"><?php echo e(theme_option('action_button_text')); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php if(is_plugin_active('ecommerce')): ?>
        <?php echo Theme::partial('ecommerce.cart-sidebar'); ?>

    <?php endif; ?>
</header>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/top-navigation.blade.php ENDPATH**/ ?>