<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <?php echo Theme::partial('header-meta'); ?>


        <?php echo Theme::header(); ?>


        <?php if(theme_option('animation_enabled', 'yes') !== 'yes'): ?>
            <style>
                .img-reveal {
                    visibility: visible;
                }
            </style>
        <?php endif; ?>
    </head>
    <body <?php if(BaseHelper::isRtlEnabled()): ?> dir="rtl" <?php endif; ?>>
        <?php echo Theme::partial('dropdown-menu-mobile'); ?>


        <?php echo Theme::partial('preloader'); ?>


        <?php echo apply_filters(THEME_FRONT_BODY, null); ?>

        <header>
            <?php echo Theme::partial('top-navigation'); ?>

        </header>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/header.blade.php ENDPATH**/ ?>