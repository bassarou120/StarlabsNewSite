<?php if(Cart::instance('cart')->count() > 0 && Cart::instance('cart')->products()->count() > 0): ?>
    <div>
        <?php if(EcommerceHelper::isTaxEnabled()): ?>
            <div class="row mb-15">
                <div class="col-6"><strong><?php echo e(__('Sub Total:')); ?></strong></div>
                <div class="col-6 text-end"><?php echo e(format_price(Cart::instance('cart')->rawSubTotal())); ?></div>
            </div>
            <div class="row mb-15">
                <div class="col-6"><strong><?php echo e(__('Tax:')); ?></strong></div>
                <div class="col-6 text-end"><?php echo e(format_price(Cart::instance('cart')->rawTax())); ?></div>
            </div>
        <?php else: ?>
            <div class="row mb-15">
                <div class="col-6"><strong><?php echo e(__('Sub Total:')); ?></strong></div>
                <div class="col-6 text-end"><?php echo e(format_price(Cart::instance('cart')->rawSubTotal())); ?></div>
            </div>
        <?php endif; ?>
        <div class="row mb-15">
            <div class="col-6"><strong><?php echo e(__('Total')); ?></strong></div>
            <div class="col-6 text-end"><?php echo e(format_price(Cart::instance('cart')->rawSubTotal() + Cart::instance('cart')->rawTax())); ?></div>
        </div>
    </div>
    <div class="cart-action">
        <a class="btn btn-brand-1 hover-up" href="<?php echo e(route('public.cart')); ?>"><?php echo e(__('View Cart')); ?></a>
        <a class="btn btn-brand-1 hover-up" href="<?php echo e(route('public.checkout.information', OrderHelper::getOrderSessionToken())); ?>"><?php echo e(__('Checkout')); ?></a>
    </div>
<?php endif; ?>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/ecommerce/cart/cart-footer.blade.php ENDPATH**/ ?>