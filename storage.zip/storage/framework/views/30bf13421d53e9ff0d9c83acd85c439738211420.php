<?php
    Assets::addScripts(['colorpicker'])->addStyles(['colorpicker']);
?>

<div
    class="input-group color-picker"
    data-color="<?php echo e($value ?? '#000'); ?>"
>
    <?php echo Form::text($name, $value ?? '#000', array_merge(['class' => 'form-control'], $attributes)); ?>

    <span class="input-group-text">
        <span class="input-group-text colorpicker-input-addon"><i></i></span>
    </span>
</div>

<?php if (! $__env->hasRenderedOnce('112e6aa2-3901-4d62-a75b-b861553f9449')): $__env->markAsRenderedOnce('112e6aa2-3901-4d62-a75b-b861553f9449'); ?>
    <?php if(request()->ajax()): ?>
        <?php echo Assets::scriptToHtml('colorpicker'); ?>

        <?php echo Assets::styleToHtml('colorpicker'); ?>

    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/base/resources/views/forms/partials/color.blade.php ENDPATH**/ ?>