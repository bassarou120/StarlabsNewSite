<?php if(Cart::instance('cart')->count() > 0 && Cart::instance('cart')->products()->count() > 0): ?>
    <?php
        $products = Cart::instance('cart')->products();
    ?>
    <?php if(count($products)): ?>
        <?php $__empty_1 = true; $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $product = $products->find($cartItem->id);
            ?>
            <?php if(! $product) continue; ?>
            <div class="row cart-item mb-20">
                <div class="col-4 product-image">
                    <a href="<?php echo e($product->original_product->url); ?>">
                        <img src="<?php echo e(RvMedia::getImageUrl($product->image)); ?>"/>
                    </a>
                </div>
                <div class="col-7 product-info">
                    <a href="<?php echo e($product->original_product->url); ?>" class="product-name"><?php echo e($product->name); ?></a>
                    <p class="product-price"><?php echo e(format_price($cartItem->price)); ?>

                        <?php if($product->front_sale_price != $product->price): ?>
                            <small class="text-secondary text-sm">
                                <del><?php echo e(format_price($product->price)); ?></del>
                            </small>
                        <?php endif; ?>
                        (x<?php echo e($cartItem->qty); ?>)
                    </p>
                    <p class="product-attributes">
                        <small>
                            <small><?php echo e($cartItem->options['attributes'] ?? ''); ?></small>
                        </small>
                    </p>
                </div>
                <div class="col-1">
                    <a href="<?php echo e(route('public.cart.remove', $cartItem->rowId)); ?>" class="remove-cart-item-sidebar">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="height: 16px; width: 16px;">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9.75L14.25 12m0 0l2.25 2.25M14.25 12l2.25-2.25M14.25 12L12 14.25m-2.58 4.92l-6.375-6.375a1.125 1.125 0 010-1.59L9.42 4.83c.211-.211.498-.33.796-.33H19.5a2.25 2.25 0 012.25 2.25v10.5a2.25 2.25 0 01-2.25 2.25h-9.284c-.298 0-.585-.119-.796-.33z" />
                        </svg>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="cart_no_items py-3 px-3">
                <span class="cart-empty-message"><?php echo e(__('No products in the cart.')); ?></span>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php else: ?>
    <div class="cart_no_items text-center">
        <span class="cart-empty-message"><?php echo e(__('No products in the cart.')); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/ecommerce/cart/cart-content.blade.php ENDPATH**/ ?>