<div class="image-box">
    <input
        class="image-data"
        name="<?php echo e($name); ?>"
        type="hidden"
        value="<?php echo e($value); ?>"
        <?php echo Html::attributes(Arr::except((array) $attributes, ['action'])); ?>

    >
    <?php if(!is_in_admin(true) || !auth()->check()): ?>
        <input
            class="media-image-input"
            type="file"
            style="display: none;"
            <?php if($name): ?> name="<?php echo e($name); ?>_input" <?php endif; ?>
            <?php if(!isset($attributes['action']) || $attributes['action'] == 'select-image'): ?> accept="image/*" <?php endif; ?>
            <?php echo Html::attributes(Arr::except((array) $attributes, ['action'])); ?>

        >
    <?php endif; ?>
    <div class="preview-image-wrapper <?php if(!($allowThumb = Arr::get($attributes, 'allow_thumb', true))): ?> preview-image-wrapper-not-allow-thumb <?php endif; ?>">
        <img
            class="preview_image"
            data-default="<?php echo e($defaultImage = Arr::get($attributes, 'default_image', RvMedia::getDefaultImage())); ?>"
            src="<?php echo e($image ?? RvMedia::getImageUrl($value, $allowThumb ? 'thumb' : null, false, $defaultImage)); ?>"
            alt="<?php echo e(trans('core/base::base.preview_image')); ?>"
            <?php if($allowThumb): ?> width="150" <?php endif; ?>
        >
        <a
            class="btn_remove_image"
            title="<?php echo e(trans('core/base::forms.remove_image')); ?>"
        >
            <i class="fa fa-times"></i>
        </a>
    </div>
    <div class="image-box-actions">
        <a
            class="<?php if(is_in_admin(true) && auth()->check()): ?> btn_gallery <?php else: ?> media-select-image <?php endif; ?>"
            data-result="<?php echo e($name); ?>"
            data-action="<?php echo e($attributes['action'] ?? 'select-image'); ?>"
            data-allow-thumb="<?php echo e($allowThumb == true); ?>"
            href="#"
        >
            <?php echo e(trans('core/base::forms.choose_image')); ?>

        </a>
    </div>
</div>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/base/resources/views/forms/partials/image.blade.php ENDPATH**/ ?>