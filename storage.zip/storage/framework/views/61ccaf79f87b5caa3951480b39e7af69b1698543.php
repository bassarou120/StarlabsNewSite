<nav aria-label="Progress">
    <ol
        class="divide-y divide-gray-300 rounded-md border border-gray-300 md:flex md:divide-y-0"
        role="list"
    >
        <?php echo $__env->make('packages/installer::partials.step-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('packages/installer::partials.step-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('packages/installer::partials.step-3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('packages/installer::partials.step-4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('packages/installer::partials.step-5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ol>
</nav>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/packages/installer/resources/views/partials/progress.blade.php ENDPATH**/ ?>