<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'a74ad8dfacd4f985eb3977517615ce25::layouts.base','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('core::layouts.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="display: none;">
        <svg xmlns="http://www.w3.org/2000/svg">
            <symbol
                class="icon-symbol--loaded"
                id="select-chevron"
            ><svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                >
                    <path d="M10 16l-4-4h8l-4 4zm0-12L6 8h8l-4-4z"></path>
                </svg></symbol>
        </svg>
    </div>

    <div class="page-wrapper">
        <?php echo $__env->make('core/base::layouts.partials.top-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="clearfix"></div>
        <div class="page-container">
            <div class="page-sidebar-wrapper">
                <div class="page-sidebar navbar-collapse collapse">
                    <div class="sidebar">
                        <div class="sidebar-content">
                            <ul
                                class="page-sidebar-menu page-header-fixed <?php echo e(session()->get('sidebar-menu-toggle') ? 'page-sidebar-menu-closed' : ''); ?>"
                                data-keep-expanded="false"
                                data-auto-scroll="false"
                                data-slide-speed="200"
                            >
                                <?php echo $__env->make('core/base::layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-content-wrapper">
                <div
                    class="page-content <?php if(Route::currentRouteName() == 'media.index'): ?> rv-media-integrate-wrapper <?php endif; ?>"
                    style="min-height: 100vh"
                >
                    <?php echo Breadcrumbs::render('main', PageTitle::getTitle(false)); ?>

                    <div class="clearfix"></div>
                    <div id="main">
                        <?php echo apply_filters('core_layout_before_content', null); ?>

                        <?php echo $__env->yieldContent('content'); ?>
                        <?php echo apply_filters('core_layout_after_content', null); ?>

                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php echo $__env->make('core/base::layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

     <?php $__env->slot('footer', null, []); ?> 
        <?php echo $__env->make('core/media::partials.media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/base/resources/views/layouts/master.blade.php ENDPATH**/ ?>