<div
    class="modal fade"
    id="product-quick-view-modal"
    aria-labelledby="product-quick-view-label"
    aria-hidden="true"
    tabindex="-1"
>
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-xl">
        <div class="modal-content position-relative">
            <button
                class="btn-close"
                data-bs-dismiss="modal"
                type="button"
                aria-label="Close"
            ></button>
            <div class="modal-body">
                <div class="product-modal-content py-5">

                </div>
            </div>
            <div class="modal-loading"></div>
        </div>
    </div>
</div>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/ecommerce/quick-view-modal.blade.php ENDPATH**/ ?>