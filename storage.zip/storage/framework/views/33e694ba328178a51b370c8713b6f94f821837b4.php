<?php if (! $__env->hasRenderedOnce('c3db434a-ed0b-436b-a30d-c02f4f98072e')): $__env->markAsRenderedOnce('c3db434a-ed0b-436b-a30d-c02f4f98072e'); ?>
    <li class="dropdown dropdown-extended dropdown-inbox">
        <a
            class="dropdown-toggle dropdown-header-name"
            id="open-notification"
            data-href="<?php echo e(route('notifications.update-notifications-count')); ?>"
            href="<?php echo e(route('notifications.get-notification')); ?>"
        >
            <input
                class="current-page"
                type="hidden"
                value="1"
            >
            <i class="fas fa-bell"></i>
            <?php if($countNotificationUnread): ?>
                <span class="badge badge-default"> <?php echo e($countNotificationUnread); ?> </span>
            <?php endif; ?>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/base/resources/views/notification/notification.blade.php ENDPATH**/ ?>