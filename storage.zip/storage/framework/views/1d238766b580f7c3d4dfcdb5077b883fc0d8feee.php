<?php echo Theme::partial('header'); ?>


<section class="section">
    <?php echo Theme::content(); ?>

</section>

<?php echo Theme::partial('footer'); ?>

<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/layouts/full-width.blade.php ENDPATH**/ ?>