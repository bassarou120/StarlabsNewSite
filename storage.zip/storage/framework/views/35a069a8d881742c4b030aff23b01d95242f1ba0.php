<?php
    $id = $attributes['id'] ?? 'onoffswitch_' . $name . '_' . md5($name);
?>
<div class="onoffswitch">
    <input
        name="<?php echo e($name); ?>"
        type="hidden"
        value="0"
    >
    <input
        class="onoffswitch-checkbox"
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        type="checkbox"
        value="1"
        <?php if($value): ?> checked <?php endif; ?>
        <?php echo Html::attributes($attributes); ?>

    >
    <label
        class="onoffswitch-label"
        for="<?php echo e($id); ?>"
    >
        <span class="onoffswitch-inner"></span>
        <span class="onoffswitch-switch"></span>
    </label>
</div>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/base/resources/views/forms/partials/on-off.blade.php ENDPATH**/ ?>