<?php echo dynamic_sidebar('pre_footer_sidebar'); ?>

<footer class="footer">
    <div class="footer-1">
        <div class="container">
            <div class="row">
                <?php echo dynamic_sidebar('footer_menu'); ?>

            </div>
        </div>
    </div>
    <div class="footer-2">
        <div class="container">
            <div class="footer-bottom">
                <div class="row">
                    <div class="col-lg-6 col-md-12 text-center text-lg-start">
                        <?php echo Menu::renderMenuLocation('footer-bottom-menu', [
                                'view'    => 'footer-bottom-menu',
                                'options' => ['class' => 'menu-bottom'],
                            ]); ?>

                    </div>
                    <?php if($copyright = theme_option('copyright')): ?>
                        <div class="col-lg-6 col-md-12 text-center text-lg-end"><span class="color-grey-300 font-md"><?php echo BaseHelper::clean($copyright); ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</footer>
<div>
    <?php if(is_plugin_active('ecommerce')): ?>
        <?php echo Theme::partial('ecommerce.quick-view-modal'); ?>

    <?php endif; ?>
</div>
    <script>
        'use strict';
        window.isRtl = <?php echo e(BaseHelper::siteLanguageDirection() === 'rtl' ? 'true' : 'false'); ?>;
        window.siteConfig = {
            "url" : "<?php echo e(route('public.index')); ?>",
            <?php if(is_plugin_active('ecommerce')): ?>
                <?php if(EcommerceHelper::isCartEnabled()): ?>
                    "ajaxCount": "<?php echo e(route('public.ajax.cart-count')); ?>",
                    "ajaxCartSidebar": "<?php echo e(route('public.ajax.cart-sidebar')); ?>",
                    "cartUrl": "<?php echo e(route('public.cart')); ?>",
                <?php endif; ?>
                <?php if(EcommerceHelper::isWishlistEnabled()): ?>
                    "wishlistUrl": "<?php echo e(route('public.wishlist')); ?>",
                <?php endif; ?>
                <?php if(EcommerceHelper::isCompareEnabled()): ?>
                    "compareUrl": "<?php echo e(route('public.compare')); ?>",
                <?php endif; ?>
            <?php endif; ?>
        };
    </script>
        <?php echo Theme::footer(); ?>

    </body>
</html>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/themes/iori/partials/footer.blade.php ENDPATH**/ ?>