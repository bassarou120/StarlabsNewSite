<link
    href="https://www.google.com"
    rel="preconnect"
>
<link
    href="https://www.gstatic.com"
    rel="preconnect"
    crossorigin
>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/plugins/captcha/resources/views/header-meta.blade.php ENDPATH**/ ?>