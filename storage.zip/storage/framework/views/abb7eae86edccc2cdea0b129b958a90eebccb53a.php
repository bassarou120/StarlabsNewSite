<div class="dashboard_widget_msg">
    <p
        class="smiley"
        aria-hidden="true"
    ></p>
    <p><?php echo e(isset($message) ? $message : trans('core/base::tables.no_data')); ?></p>
</div>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/core/dashboard/resources/views/partials/no-data.blade.php ENDPATH**/ ?>