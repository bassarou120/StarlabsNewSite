<div class="note note-success resume-setup-wizard-wrapper">
    <p><?php echo BaseHelper::clean(
        trans('packages/get-started::get-started.setup_wizard_button', [
            'link' => Html::link(
                '#',
                trans('packages/get-started::get-started.click_here'),
                ['class' => 'resume-setup-wizard'],
                null,
                false,
            )->toHtml(),
        ]),
    ); ?></p>
</div>
<?php /**PATH /Users/bassarouyacoubou/Documents/TOPTIC/STARLAB SITE/StarlabsNewSite/platform/packages/get-started/resources/views/setup-wizard-notice.blade.php ENDPATH**/ ?>